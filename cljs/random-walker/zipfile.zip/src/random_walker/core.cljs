(ns random-walker.core
  (:require [quil.core :as q :include-macros true]
            [quil.middleware :as m]))

(def width 1280)
(def height 800)
(def step 4)

(defn abs [v]
  (if (< v 0)
    (- v)
    v))

(defn legal-y? [y]
  (<= (abs y) (- (/ height 2) step) ))

(defn legal-x? [x]
  (<= (abs x) (- (/ width 2) step) ))

(defn legal-pos? [[x y]]
  (and (legal-x? x)
       (legal-y? y)))

(defn update-pos [pos vel speed]
  (let [new-pos (vec (map + pos (map #(* speed %1) vel )))]
    (if (legal-pos? new-pos)
      new-pos
      pos)))

(defn update-vel [vel]
  (let [choices {0 [1 0] 
              1 [-1 0] 
              2 [0 1] 
              3 [0 -1]
              4 vel}]
  (get  choices (rand-int 5))))


(defn update-state [state]
  (loop [new-state (assoc state :draw-points [])
         i 0 ]
    (if (> i (:loop-count state))
      new-state
      (recur (-> new-state
               (update :draw-points conj (:pos new-state))
               (update :pos update-pos  
                       (:vel new-state) (:speed new-state))   
               (update :vel update-vel))
             (inc i)))))


(defn draw-char [state]
  (q/no-stroke)
  (q/fill 80 160 160 40)
  (doseq [[x y]  (:draw-points state)]
    (q/with-translation [(/ width 2) (/ height 2)]
    (q/ellipse x y 4 4))))

(defn draw-border [state]
  (q/no-stroke)
  (q/fill 255)
  (let [step  (:pix-per-unit state)
        roundoff (* step 0.2)]
    (doseq [x (range 0 width step)]
      (q/rect x 0      step step roundoff)
      (q/rect x (- height step) step step roundoff))
    (doseq [y (range step height step)]
      (q/rect 0     y step step roundoff)
      (q/rect (- width step) y step step roundoff)))
  state)

(defn draw-state [state]
  (draw-char state)
  ;(q/no-loop)
  (when (:play? state)
    (q/start-loop)
    (q/no-loop))
  state)

(defn toggle-play [state]
  (update state :play? #(not %)))


(defn key-press [state event]
  (let [k (:key event)]
    (cond  (= k :up) (update state :speed toggle-speed)
          true state)))

(def init-state {:pix-per-unit step 
               :pos [(/ step 2) (/ step 2) ]
               :draw-points []
               :vel [1 0]
               :speed step
               :loop-count 100
               :play? true})

(update-state init-state)

(toggle-play init-state)


(defn setup []
  (q/frame-rate 30)
  (let [state init-state]
    (draw-border state)
    (assoc state :graphic (q/create-graphics 100 height))))

(q/defsketch random-walker
  :host "random-walker"
  :size [width height]
  :setup setup
  :key-pressed key-press
  :update update-state
  :draw draw-state
  :middleware [m/fun-mode
               m/pause-on-error])


